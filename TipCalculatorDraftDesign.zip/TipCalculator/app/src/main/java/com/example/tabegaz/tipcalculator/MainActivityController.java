package com.example.tabegaz.tipcalculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivityController extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_view);
    }
}
